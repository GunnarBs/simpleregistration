<?php defined('_JEXEC') or die('Restricted access');

/**
* @version		$Id: simpleregistration.php 2013-03-17 15:28:00Z zanardi $
* @package		GiBi SimpleRegistration
* @copyright	Copyright (C) 2011-2013 GiBiLogic. All rights reserved.
* @license		GNU/GPL
*/

jimport('joomla.application.component.helper');
require_once(JPATH_COMPONENT.'/controller.php');
$controller = new SimpleregistrationController();
$controller->execute(JRequest::getCmd('task', null, 'default', 'cmd'));
$controller->redirect();
